
import telebot

TOKEN = '8410018880:AAH2Q-Ztw-cp7HCXu70Nh4E7ccyCuscmNvo'
bot = telebot.TeleBot(TOKEN)

teams = {}

@bot.message_handler(commands=['start'])
def welcome(message):
    bot.reply_to(message, "Assalomu alaykum! Botga xush kelibsiz. /add_team orqali jamoa qo‘shing.")

@bot.message_handler(commands=['add_team'])
def add_team(message):
    name = message.text.split(' ', 1)
    if len(name) < 2:
        bot.reply_to(message, "Jamoa nomini kiriting: /add_team Paxtakor")
        return
    team_name = name[1]
    teams[team_name] = {'gollar': 0, 'sariq': 0, 'qizil': 0}
    bot.reply_to(message, f"✅ {team_name} jamoasi qo‘shildi.")

@bot.message_handler(commands=['goal'])
def add_goal(message):
    name = message.text.split(' ', 1)
    if len(name) < 2 or name[1] not in teams:
        bot.reply_to(message, "Jamoa topilmadi yoki noto‘g‘ri: /goal Paxtakor")
        return
    teams[name[1]]['gollar'] += 1
    bot.reply_to(message, f"⚽ {name[1]} gol urdi!")

@bot.message_handler(commands=['yellow'])
def yellow_card(message):
    name = message.text.split(' ', 1)
    if len(name) < 2 or name[1] not in teams:
        bot.reply_to(message, "Jamoa topilmadi: /yellow Paxtakor")
        return
    teams[name[1]]['sariq'] += 1
    bot.reply_to(message, f"🟨 {name[1]} sariq kartochka oldi!")

@bot.message_handler(commands=['red'])
def red_card(message):
    name = message.text.split(' ', 1)
    if len(name) < 2 or name[1] not in teams:
        bot.reply_to(message, "Jamoa topilmadi: /red Paxtakor")
        return
    teams[name[1]]['qizil'] += 1
    bot.reply_to(message, f"🟥 {name[1]} qizil kartochka oldi!")

@bot.message_handler(commands=['stats'])
def show_stats(message):
    if not teams:
        bot.reply_to(message, "Statistika yo‘q.")
        return
    result = "📊 Jamoalar statistikasi:
"
    for team, stats in teams.items():
        result += f"\n{team} — ⚽ {stats['gollar']}, 🟨 {stats['sariq']}, 🟥 {stats['qizil']}"
    bot.reply_to(message, result)

bot.polling()
